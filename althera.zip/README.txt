Thank you for downloading Althera Font!

📁 Files included:
- Althera.otf
  Althera is a refined modern serif crafted for editorial elegance and premium branding.
  Designed with balanced proportions and smooth, controlled contrast, Althera delivers a sophisticated voice while maintaining excellent readability—making it ideal for both striking headlines and extended text.

- License - Free for personal use.txt

🛠 How to install:
- Double-click the font file and click “Install”
- Or drag the .otf file into your Fonts folder (Windows/Mac)

📌 License:
>> You downloaded the Free for personal use license.
>> For Commercial use & full version: https://syauqistudio.gumroad.com/l/althera


📬 Contact:
Email: syauqistudios@gmail.com

Follow me for more fonts & updates:
Instagram: @syauqistudio
Behance: behance.net/syauqistudio

Enjoy and tag me if you use it!